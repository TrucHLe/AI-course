### Compile

Use C++ 11 to compile on the command line.

```sh
$ g++ -std=c++11 *.cpp -o main
$ ./main
```
