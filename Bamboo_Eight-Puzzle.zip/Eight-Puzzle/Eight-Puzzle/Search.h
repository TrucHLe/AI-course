//
//  Search.h
//  Eight-Puzzle
//
//  Created by Truc Le on 9/15/15.
//  Copyright (c) 2015 Truc Le. All rights reserved.
//

#ifndef __Eight_Puzzle__Search__
#define __Eight_Puzzle__Search__

#include <stdio.h>



#endif /* defined(__Eight_Puzzle__Search__) */
